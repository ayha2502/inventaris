const {Sequelize} = require('sequelize');

const db = new Sequelize('anan4589_authentic_db', 'anan4589_admin', '5wiPil4{9@S#', {
    host: "api2.projecttest-syazliananuro.site",
    dialect: "mysql"
});

module.exports = db;